import React from 'react'

const Footer = () => {
  return (
    <div className='Footer container-fluid'>
        <div className='Container FText'>@2023 ByteBridge. All Rights Reserved.</div>
      
    </div>
  )
}

export default Footer
