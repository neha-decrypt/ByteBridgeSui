import logo from './logo.svg';
import './App.css';
import Header from './Components/Header/Header';
import './Style/style.scss';
import StakePortal from './Pages/StakePortal';
import Footer from './Components/Footer/Footer';

function App() {
  return (
    <>
    <div className="App ">
     <Header/>
     <StakePortal />
     <Footer />
    </div>
    </>
  );
}

export default App;
