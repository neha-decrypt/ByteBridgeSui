import React, { useState } from 'react'

const StakePortal = () => {
    const [withdraw, setWithdraw] = useState(true)
    const handleChangeToWithdraw = () => {
        setWithdraw(true);
    };

    const handleChangeToDeposit = () => {
        setWithdraw(false);
    };
    return (
        <div className='StakePortal container-fluid d-flex align-items-center justify-content-center'>
            <img className='BGUP' src='assets/bgImg.png' />
            <div className='BGUPCIRCLE'></div>
            <div className='BGDNCIRCLE'></div>

            <img className='BGDN' src='assets/bgImgDown.png' />


            <div className='container-fluid' >
                <div className='row'>

                    <div className='col-md-6  d-flex align-items-center justify-content-center' >
                        <div style={{ maxWidth: '600px' }}>
                            <div className='HeadingText'>Stake $portal</div>
                            <div className='paraText'>Lorem ipsum dolor sit amet consectetur. In justo a integer justo arcu mauris enim est scelerisque. Posuere tempor id at sit aliquam venenatis amet eget. Feugiat leo elementum eu molestie.</div>
                        </div>
                    </div>
                    <div className='col-md-6 BGVid d-flex align-items-center justify-content-center'>
                        <div className='stakeForm d-flex align-items-center justify-content-center'>
                            <div className='UpperSwitch'>
                                <div
                                    className={`DepositBtn ${!withdraw ? 'active' : ''}`}
                                    onClick={handleChangeToDeposit}
                                >
                                    Deposit
                                </div>
                                <div
                                    className={`DepositBtn ${withdraw ? 'active' : ''}`}
                                    onClick={handleChangeToWithdraw}
                                >
                                    Withdraw
                                </div>
                            </div>


                            {withdraw ? (
                                <>
                                    <div className='FormText'>From</div>
                                    <div className='EtheriumDiv'>
                                        <div>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <circle cx="12" cy="12" r="12" fill="#547FEF" />
                                                <g opacity="0.6">
                                                    <mask id="mask0_2799_2194" style={{ maskType: 'luminance' }} maskUnits="userSpaceOnUse" x="8" y="10" width="9" height="6">
                                                        <path d="M8 10.4187H16.9965V15.123H8V10.4187Z" fill="white" />
                                                    </mask>
                                                    <g mask="url(#mask0_2799_2194)">
                                                        <path d="M12.4991 10.4187L8 12.4649L12.4991 15.123L16.9965 12.4649L12.4991 10.4187Z" fill="#BFCCF9" />
                                                    </g>
                                                </g>
                                                <mask id="mask1_2799_2194" style={{ maskType: 'luminance' }} maskUnits="userSpaceOnUse" x="8" y="5" width="5" height="11">
                                                    <path d="M8 5H12.4991V15.123H8V5Z" fill="white" />
                                                </mask>
                                                <g mask="url(#mask1_2799_2194)">
                                                    <path d="M8 12.4649L12.4991 15.123V5L8 12.4649Z" fill="white" />
                                                </g>
                                                <mask id="mask2_2799_2194" style={{ maskType: 'luminance' }} maskUnits="userSpaceOnUse" x="12" y="5" width="5" height="11">
                                                    <path d="M12.499 5H16.9981V15.123H12.499V5Z" fill="white" />
                                                </mask>
                                                <g mask="url(#mask2_2799_2194)">
                                                    <path d="M12.499 5V15.123L16.9964 12.4649L12.499 5Z" fill="#BECCF9" />
                                                </g>
                                                <mask id="mask3_2799_2194" style={{ maskType: 'luminance' }} maskUnits="userSpaceOnUse" x="8" y="13" width="5" height="7">
                                                    <path d="M8 13.3174H12.4991V19.6557H8V13.3174Z" fill="white" />
                                                </mask>
                                                <g mask="url(#mask3_2799_2194)">
                                                    <path d="M8 13.3174L12.4991 19.6557V15.9754L8 13.3174Z" fill="white" />
                                                </g>
                                                <mask id="mask4_2799_2194" style={{ maskType: 'luminance' }} maskUnits="userSpaceOnUse" x="12" y="13" width="5" height="7">
                                                    <path d="M12.499 13.3174H16.9999V19.6557H12.499V13.3174Z" fill="white" />
                                                </mask>
                                                <g mask="url(#mask4_2799_2194)">
                                                    <path d="M12.499 15.9754V19.6557L16.9999 13.3174L12.499 15.9754Z" fill="#C0CDFA" />
                                                </g>
                                            </svg>
                                        </div>
                                        <div>Ethereum</div>
                                    </div>
                                    <div className='mt-4 TextInputDiv'>
                                        <input type='text' placeholder='0.00' maxLength={20} className='TextInput' />
                                        <div className='textAbsolute'>$Portal</div>
                                    </div>
                                    <div className='d-flex align-items-center justify-content-around w-100 mt-1' >
                                        <div className='AVAIText'>Available: 0 $PORTAL </div>
                                        <div className='greenText'>Use Max</div>
                                    </div>
                                    <div className='FormText'>To</div>
                                    <div className='EtheriumDiv'>
                                        <div style={{ whiteSpace: 'nowrap' }}>0x243214157bh323452</div>
                                    </div>
                                    <button className='ConnectWallet'>Locked Until 08/01/2025</button>
                                </>
                            ) : (
                                <>
                                    <div className='FormText'>From</div>
                                    <div className='EtheriumDiv'>
                                        <div>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <circle cx="12" cy="12" r="12" fill="#547FEF" />
                                                <g opacity="0.6">
                                                    <mask id="mask0_2799_2194" style={{ maskType: 'luminance' }} maskUnits="userSpaceOnUse" x="8" y="10" width="9" height="6">
                                                        <path d="M8 10.4187H16.9965V15.123H8V10.4187Z" fill="white" />
                                                    </mask>
                                                    <g mask="url(#mask0_2799_2194)">
                                                        <path d="M12.4991 10.4187L8 12.4649L12.4991 15.123L16.9965 12.4649L12.4991 10.4187Z" fill="#BFCCF9" />
                                                    </g>
                                                </g>
                                                <mask id="mask1_2799_2194" style={{ maskType: 'luminance' }} maskUnits="userSpaceOnUse" x="8" y="5" width="5" height="11">
                                                    <path d="M8 5H12.4991V15.123H8V5Z" fill="white" />
                                                </mask>
                                                <g mask="url(#mask1_2799_2194)">
                                                    <path d="M8 12.4649L12.4991 15.123V5L8 12.4649Z" fill="white" />
                                                </g>
                                                <mask id="mask2_2799_2194" style={{ maskType: 'luminance' }} maskUnits="userSpaceOnUse" x="12" y="5" width="5" height="11">
                                                    <path d="M12.499 5H16.9981V15.123H12.499V5Z" fill="white" />
                                                </mask>
                                                <g mask="url(#mask2_2799_2194)">
                                                    <path d="M12.499 5V15.123L16.9964 12.4649L12.499 5Z" fill="#BECCF9" />
                                                </g>
                                                <mask id="mask3_2799_2194" style={{ maskType: 'luminance' }} maskUnits="userSpaceOnUse" x="8" y="13" width="5" height="7">
                                                    <path d="M8 13.3174H12.4991V19.6557H8V13.3174Z" fill="white" />
                                                </mask>
                                                <g mask="url(#mask3_2799_2194)">
                                                    <path d="M8 13.3174L12.4991 19.6557V15.9754L8 13.3174Z" fill="white" />
                                                </g>
                                                <mask id="mask4_2799_2194" style={{ maskType: 'luminance' }} maskUnits="userSpaceOnUse" x="12" y="13" width="5" height="7">
                                                    <path d="M12.499 13.3174H16.9999V19.6557H12.499V13.3174Z" fill="white" />
                                                </mask>
                                                <g mask="url(#mask4_2799_2194)">
                                                    <path d="M12.499 15.9754V19.6557L16.9999 13.3174L12.499 15.9754Z" fill="#C0CDFA" />
                                                </g>
                                            </svg>
                                        </div>
                                        <div>Ethereum</div>
                                    </div>
                                    <div className='mt-4 TextInputDiv'>
                                        <input type='text' placeholder='0.00' maxLength={20} className='TextInput' />
                                        <div className='textAbsolute'>$Portal</div>
                                    </div>
                                    <div className='FormText'>To</div>
                                    <div className='EtheriumDiv'>
                                        <div style={{ whiteSpace: 'nowrap' }}>Portal XP Contract</div>
                                    </div>
                                    <button className='ConnectWallet'>Connect Wallet to Start</button>
                                </>
                            )}



                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default StakePortal
